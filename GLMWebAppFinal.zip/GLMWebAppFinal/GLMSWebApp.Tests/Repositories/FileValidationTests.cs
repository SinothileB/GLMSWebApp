﻿using GLMSWebApp.Helpers;

namespace GLMSWebApp.Tests.Helpers
{
    public class FileValidationTests
    {
        [Fact]
        public void IsPdfFile_ShouldReturnTrue_ForPdfFile()
        {
            bool result = FileValidationHelper.IsPdfFile("contract.pdf");

            Assert.True(result);
        }

        [Fact]
        public void IsPdfFile_ShouldReturnFalse_ForExeFile()
        {
            bool result = FileValidationHelper.IsPdfFile("virus.exe");

            Assert.False(result);
        }

        [Fact]
        public void IsPdfFile_ShouldReturnFalse_ForEmptyFileName()
        {
            bool result = FileValidationHelper.IsPdfFile("");

            Assert.False(result);
        }
    }
}