﻿using GLMSWebApp.Data;
using GLMSWebApp.Models;
using GLMSWebApp.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Net.Http.Json;


namespace GLMSWebApp.Controllers
{
    public class ServiceRequestsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceRequestRepository _serviceRequestRepository;

        private readonly IHttpClientFactory _httpClientFactory;
        public ServiceRequestsController(ApplicationDbContext context,IHttpClientFactory httpClientFactory,IServiceRequestRepository serviceRequestRepository)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
            _serviceRequestRepository = serviceRequestRepository;
        }

        public async Task<IActionResult> Index()
        {
            var serviceRequests = await _serviceRequestRepository.GetAllAsync();

            return View(serviceRequests);
        }

        public IActionResult Create()
        {
            ViewBag.ContractId = _context.Contracts
          .Include(c => c.Client)
          .Select(c => new SelectListItem
          {
              Value = c.ContractId.ToString(),
              Text = c.Client.Name + " - " + c.Status + " - Contract #" + c.ContractId
          }).ToList();
            return View();
        }

            [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ServiceRequest serviceRequest)
        {
            var contract = await _context.Contracts
                .FirstOrDefaultAsync(c => c.ContractId == serviceRequest.ContractId);

            if (contract == null)
            {
                ModelState.AddModelError("", "Selected contract does not exist.");
            }
            else if (contract.Status == "Expired" || contract.Status == "On Hold")
            {
                ModelState.AddModelError("", "A service request cannot be created for an expired or on-hold contract.");
            }

            if (ModelState.IsValid)
            {
                var exchangeRate = await GetUsdToZarRateAsync();
                serviceRequest.CostZar = serviceRequest.CostUsd * exchangeRate;

                await _serviceRequestRepository.AddAsync(serviceRequest);

                return RedirectToAction(nameof(Index));
            }

            /*ViewBag.ContractId = new SelectList(_context.Contracts, "ContractId", "ContractId", serviceRequest.ContractId);*/

            ViewBag.ContractId = _context.Contracts.Include(c => c.Client)

               .Select(c => new SelectListItem
                    {
                       Value = c.ContractId.ToString(),
                       Text = c.Client.Name + " - " + c.Status + " - Contract #" + c.ContractId,
                       Selected = c.ContractId == serviceRequest.ContractId
                    }).ToList();

            return View(serviceRequest);
        }
        public async Task<IActionResult> Edit(int id)
        {
            var serviceRequest = await _serviceRequestRepository.GetByIdAsync(id);

            if (serviceRequest == null)
            {
                return NotFound();
            }

            ViewBag.ContractId = _context.Contracts
                .Include(c => c.Client)
                .Select(c => new SelectListItem
                {
                    Value = c.ContractId.ToString(),
                    Text = c.Client.Name + " - " + c.Status + " - Contract #" + c.ContractId
                }).ToList();

            return View(serviceRequest);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ServiceRequest serviceRequest)
        {
            if (id != serviceRequest.ServiceRequestId)
            {
                return NotFound();
            }

            var contract = await _context.Contracts
                .FirstOrDefaultAsync(c => c.ContractId == serviceRequest.ContractId);

            if (contract == null)
            {
                ModelState.AddModelError("", "Selected contract does not exist.");
            }
            else if (contract.Status == "Expired" || contract.Status == "On Hold")
            {
                ModelState.AddModelError("", "A service request cannot be linked to an expired or on-hold contract.");
            }

            if (ModelState.IsValid)
            {
                var exchangeRate = await GetUsdToZarRateAsync();
                serviceRequest.CostZar = serviceRequest.CostUsd * exchangeRate;

                await _serviceRequestRepository.UpdateAsync(serviceRequest);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.ContractId = _context.Contracts
                .Include(c => c.Client)
                .Select(c => new SelectListItem
                {
                    Value = c.ContractId.ToString(),
                    Text = c.Client.Name + " - " + c.Status + " - Contract #" + c.ContractId,
                    Selected = c.ContractId == serviceRequest.ContractId

                }).ToList();

            return View(serviceRequest);
        }
        private async Task<decimal> GetUsdToZarRateAsync()
        {
            try
            {
                var client = _httpClientFactory.CreateClient();

                var response = await client.GetFromJsonAsync<ExchangeRateResponse>(
     "https://v6.exchangerate-api.com/v6/0cdfe10488c1d15eb6a1c350/latest/USD");

                if (response != null && response.conversion_rates.ContainsKey("ZAR"))
                {
                    return response.conversion_rates["ZAR"];
                }
            }
            catch
            {
                // fallback if API fails
            }

            return 16.50m;
        }
        public async Task<IActionResult> Delete(int id)
        {
            var serviceRequest = await _serviceRequestRepository.GetByIdAsync(id);

            if (serviceRequest == null)
            {
                return NotFound();
            }

            return View(serviceRequest);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _serviceRequestRepository.DeleteAsync(id);

            return RedirectToAction(nameof(Index));
        }

        public class ExchangeRateResponse
        {
            public Dictionary<string, decimal> conversion_rates { get; set; } = new();
        }
    }
}