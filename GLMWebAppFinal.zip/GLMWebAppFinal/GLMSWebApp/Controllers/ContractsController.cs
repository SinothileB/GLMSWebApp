﻿using GLMSWebApp.Data;
using GLMSWebApp.Models;
using GLMSWebApp.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.IO;
using GLMSWebApp.Helpers;

namespace GLMSWebApp.Controllers
{
    public class ContractsController : Controller
    {
        private readonly IContractRepository _contractRepository;
        private readonly ApplicationDbContext _context;

        public ContractsController(ApplicationDbContext context, IContractRepository contractRepository)
        {
            _context = context;
            _contractRepository = contractRepository;
        }

        public async Task<IActionResult> Index(
           string? searchTerm,
           string? status,
           DateTime? startDate,
           DateTime? endDate)
        {
            var contracts = await _contractRepository.SearchAsync(
                searchTerm,
                status,
                startDate,
                endDate);

            ViewBag.SearchTerm = searchTerm;
            ViewBag.Status = status;
            ViewBag.StartDate = startDate?.ToString("yyyy-MM-dd");
            ViewBag.EndDate = endDate?.ToString("yyyy-MM-dd");

            return View(contracts);
        }

        public IActionResult Create()
        {
            ViewBag.ClientId = new SelectList(_context.Clients, "ClientId", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Contract contract)
        {
            if (contract.PdfFile != null)
            {
                var extension = Path.GetExtension(contract.PdfFile.FileName).ToLower();

                /*  if (extension != ".pdf")*/
                if (!FileValidationHelper.IsPdfFile(contract.PdfFile.FileName))
                {
                    ModelState.AddModelError("PdfFile", "Only PDF files are allowed.");
                }
                else
                {
                    var fileName = Guid.NewGuid().ToString() + extension;

                    var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles");

                    if (!Directory.Exists(uploadPath))
                    {
                        Directory.CreateDirectory(uploadPath);
                    }

                    var filePath = Path.Combine(uploadPath, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await contract.PdfFile.CopyToAsync(stream);
                    }

                    contract.PdfFilePath = fileName;
                }
            }



            if (ModelState.IsValid)
            {
                await _contractRepository.AddAsync(contract);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.ClientId = new SelectList(_context.Clients, "ClientId", "Name", contract.ClientId);
            return View(contract);
        }
        public async Task<IActionResult> Edit(int id)
        {
            var contract = await _contractRepository.GetByIdAsync(id);

            if (contract == null)
            {
                return NotFound();
            }

            ViewBag.ClientId = new SelectList(_context.Clients, "ClientId", "Name", contract.ClientId);
            return View(contract);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Contract contract)
        {
            if (id != contract.ContractId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _contractRepository.UpdateAsync(contract);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.ClientId = new SelectList(_context.Clients, "ClientId", "Name", contract.ClientId);
            return View(contract);
        }
        public async Task<IActionResult> Delete(int id)
        {
            var contract = await _contractRepository.GetByIdAsync(id);

            if (contract == null)
            {
                return NotFound();
            }

            return View(contract);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                await _contractRepository.DeleteAsync(id);
                return RedirectToAction(nameof(Index));
            }
            catch (InvalidOperationException ex)
            {
                var contract = await _contractRepository.GetByIdAsync(id);

                if (contract == null)
                {
                    return NotFound();
                }

                ModelState.AddModelError("", ex.Message);
                return View("Delete", contract);
            }
        }
        public IActionResult DownloadPdf(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return NotFound();
            }

            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles", fileName);

            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            var fileBytes = System.IO.File.ReadAllBytes(filePath);

            return File(fileBytes, "application/pdf", fileName);
        }
    }
}