﻿namespace GLMSWebApp.Helpers
{
    public static class FileValidationHelper
    {
        public static bool IsPdfFile(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return false;
            }

            return Path.GetExtension(fileName).ToLower() == ".pdf";
        }
    }
}